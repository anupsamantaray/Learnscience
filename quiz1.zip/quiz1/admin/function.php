<?php
session_start();
$con=mysql_connect("localhost","root","colourfade");
$db=mysql_select_db("kriti_quiz",$con);
?>
