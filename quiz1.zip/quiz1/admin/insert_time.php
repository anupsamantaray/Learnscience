<?php
include_once("function.php");
if(isset($_POST['submit'])){
$time=htmlentities($_POST['time'],ENT_QUOTES);
$fullmark=htmlentities($_POST['fullmark'],ENT_QUOTES);
if($time!=""){
    $fet=mysql_query("select * from `time`")or die(mysql_error());
     $res=mysql_numrows($fet);
    if($res==0)
    {
    mysql_query("insert into `time` set `time`='$time',`fullmark`='$fullmark'")or die(mysql_error());
	$msg="successfully added";
    }
	else{
	    $stim=mysql_fetch_array($fet);
	    $tim=$stim['time'];
	mysql_query("update `time` set`time`='$time',`fullmark`='$fullmark' where `time`='$tim'")or die(mysql_error());;
	}
}
else{
$msg="Please Fillup All Required Fields";
}
}
header("location:time_add.php?msg=$msg");
?>
