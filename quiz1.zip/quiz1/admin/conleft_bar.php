<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" />

</head>
<body>
<div class="list_menu">
								 <ul>
										<li class="active">
											<i class="icon-chevron-right"></i> Dashboard</li>
										<li>
											<a href="class_add.php"><i class="icon-chevron-right"><img src="image/1.png" /></i>add class</a>
										</li>
										<li>
											<a href="subject_add.php"><i class="icon-chevron-right"><img src="image/1.png" /></i>add subject</a>
										</li>
										<li>
											<a href="topic_add.php"><i class="icon-chevron-right"><img src="image/1.png" /></i>add topic</a>
										</li>
										<li>
											<a href="question_add.php"><i class="icon-chevron-right"><img src="image/1.png" /></i>add question</a>
										</li>
										<li>
											<a href="edit_question.php"><i class="icon-chevron-right"><img src="image/1.png" /></i>edit answer</a>
										</li>
										<li>
											<a href="oldquestion.php"><i class="icon-chevron-right"><img src="image/1.png" /></i>add oldquestion</a>
										</li>
										<li>
											<a href="extra_add.php"><i class="icon-chevron-right"><img src="image/1.png" /></i>add ebook&video </a>
										</li>
										<li>
											<a href="time_add.php"><i class="icon-chevron-right"><img src="image/1.png" /></i>add time & mark</a>
										</li>
										<li>
											<a href="add_news.php"><i class="icon-chevron-right"><img src="image/1.png" /></i>News</a>
										</li>
										<li>
											<a href="adminlogout.php"><i class="icon-chevron-right"><img src="image/1.png" /></i>logout</a>
										</li>
										<!--<li>
											<a href="popular_sub.php"><i class="icon-chevron-right"><img src="image/1.png" /></i>popular subject</a>
										</li>
										<li>
											<a href="popular_video.php"><i class="icon-chevron-right"><img src="image/1.png" /></i>popular video</a>
										</li>-->
						  		</ul>
						</div>

</body>
</html>
