<ul>
						<li><a href="class_add.php"><span>Home</span></a></li>
						<li><a href="#"><span>Work</span></a></li>
						<li><a href="#"><span>About</span></a></li>
						<li><a href="#"><span>Services</span></a></li>
						<li><a href="#"><span>Contact</span></a></li>
</ul>