<?php
include_once("function.php");
$name=htmlentities($_POST['uname'],ENT_QUOTES);
$id=$_POST['hidden_id'];
$res=mysql_query("update `time` set `time`='$name' where `id`='$id'");
header("location:time_add.php");
?>
