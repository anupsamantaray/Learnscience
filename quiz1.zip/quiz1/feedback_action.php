<?php
include_once('function.php');
if(isset($_POST['button']))
{
    $name=htmlentities($_REQUEST['name']);
    $phone=htmlentities($_REQUEST['phone']);
    $email=htmlentities($_REQUEST['email']);
    $feed=htmlentities($_REQUEST['feedback']);
   
    
		$feedback="Thank you for contacting us";
	       $subject="email verification";
	       $from="noreply@learnscience.co.in";
                mail($email,$subject,$feedback,"From: $from\n");
		
		mail($from,$subject,$feed,"From: $email\n");
    
    header("location:index.php");
}
?>