 <div id="footer">
        <div id="footer_content">
            <div id="footer_leftbar">
                Copyright&copy; <span style="color:rgb(0, 112, 176);">2000 - 2014</span> Education To Go. All rights reserved. The material on this site cannot be reproduced or redistributed unless you have obtained prior written permission from Education To Go. 
            </div>
            <div id="footer_rightbar">
                <h5 style="border: none; font-weight: normal; margin-top: 0px; margin-bottom: 0px;">Connect with Us</h5>
                <img src="images/facebook.png" style="float: left; width:30px;"/>
                <img src="images/twitter.png" style="float: left; width:30px; margin-left: 5px;"/>
                <img src="images/google.png" style="float: left; width:30px; margin-left: 5px;"/>
                <img src="images/youtube.png" style="float: left; width:30px; margin-left: 5px;"/>
                <img src="images/pinterest.png" style="float: left; width:30px; margin-left: 5px;"/>
            </div>
        </div>
    </div>