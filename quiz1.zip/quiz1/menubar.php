 <?php include_once('function.php');?>
 <style type="text/css">
      h2{
	    margin-bottom: 0px;
	    padding-bottom: 0px !important;
      }
      #color-menubox1{
	  background:#671142;
      }
      #color-menubox1 li {
	    width:auto !important;
	    padding-left:40px;
	    padding-right:40px;
      }
      #color-menubox1 li ul li{
	    width:auto !important;
	    padding-left: 10px;
	    padding-right: 10px;
	    font-family:arial;
	    font-size:12px;
	   
	   
      }
      
       #color-menubox1 li ul li a:hover {
	    background: none;
	    
       }
       a:hover{
	    background: none !important;
       }
</style>
 
 <div id="color-menubar">
						<div id="color-menu">
								<div id="color-menubox1">
										<ul>
												<li style="background:#073974;"><a href="index.php" class="active">Home</a>
												      <ul>
													    <li style="background:#1a5fb1;"><a href="about.php">About us</a></li>
													    <li style="background:#1a5fb1;"><a href="faq.php">FAQ</a></li>
													    <li style="background:#1a5fb1;"><a href="services.php">Other Services</a></li>
												      </ul>
												</li>
												<li style="background:#517e09;"><a href="about.php">Lessons</a>
												      <ul>
													    <li style="background:#7fa838;"><a href="#">Chapter Summary</a>
														   <ul style=" ">
															<?php
															$sql1=mysql_query("select * from `student_class`");
															while($res1=mysql_fetch_array($sql1)){
															$id1=$res1['id'];
															?>
															<li style="background: #b9de73;"><a href="courses/index.php?clid=<?php echo $id1;?>">Class <?php echo $res1['class'];?></a></li><?php }?>
														   </ul>
													    </li>
													    <li style="background:#7fa838;"><a href="#">Quiz to test knowledge</a>
														   <ul style=" ">
															<?php
															$sql2=mysql_query("select * from `student_class`");
															while($res2=mysql_fetch_array($sql2)){
															$id2=$res2['id'];
															?>
															<li style="background: #b9de73;"><a href="courses/index.php?clid=<?php echo $id2;?>">Class <?php echo $res2['class'];?></a></li><?php }?>
														   </ul>
													    </li>
												      </ul>
												</li>
												<li style="background:#c57b0e;"><a href="faq.php">Remember Cards</a>
												       <ul>
													    <li style="background:#ed9e3e;"><a href="pagetest.php">Memory Cards</a></li>
													    <li style="background:#ed9e3e;"><a href="concept.php">Concept Map</a></li>
													    <li style="background:#ed9e3e;"><a href="picture.php">Picture Game</a></li>
												      </ul>
												</li>
												<li style="background:#073974;"><a href="" class="active">Our Courses</a>
														<ul>
														<?php
														$sql=mysql_query("select * from `student_class`");
														while($res=mysql_fetch_array($sql)){
														$id=$res['id'];
														?>
														<li style="background:#1a5fb1;"><a href="courses/index.php?clid=<?php echo $id;?>">Class <?php echo $res['class'];?></a>
																<!--<li style="background:#1a5fb1;"><a href="courses/index.php?clid=10">Class IX</a></li>
																<li style="background:#1a5fb1;"><a href="courses/index.php?clid=7">Class X</a></li>-->
														<?php
														}
														?>	
														</ul>
												</li>
												<li style="background:#c61831;"><a href="services.php">Quizzes</a>
												      <ul>
													    <li style="background:#f0485b;"><a href="courses/wil_index1.php">Basic Quiz</a></li>
													    <li style="background:#f0485b;"><a href="courses/wil_index1.php">Competitive Quiz</a></li>
												      </ul>
												</li>
												<li style="background:#671142; "><a href="games.php">Videos & Fun Games</a></li>
										</ul>
								</div>
						</div>
				 </div>